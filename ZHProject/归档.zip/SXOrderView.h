//
//  SXOrderView.h
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface SXOrderView : UIView

@property (nonatomic, strong) NSArray *dataArray;

@property (nonatomic, strong) UITableView *tableView;

@end

NS_ASSUME_NONNULL_END
