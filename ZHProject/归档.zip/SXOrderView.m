//
//  SXOrderView.m
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import "SXOrderView.h"
#import "SXOrderModel.h"
#import "SXOrderCell.h"
@interface SXOrderView ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) NSMutableArray *cellHeightArray;

@end

@implementation SXOrderView

- (void)setDataArray:(NSArray *)dataArray {
    _dataArray = dataArray;
    for (SXOrderModel *model in self.dataArray) {
        CGSize descSize = [model.desc boundingRectWithSize:CGSizeMake(self.width-120, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:17]} context:nil].size;
        
        CGFloat cellH = 15+50+15+15+14+15 + descSize.height;
        [self.cellHeightArray addObject:@(cellH)];
    }
    [self.tableView reloadData];
}

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.bounds style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    }
    return _tableView;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        self.cellHeightArray = @[].mutableCopy;
        [self initSubviews];
    }
    return self;
}

- (void)initSubviews {
    [self addSubview:self.tableView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.dataArray.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *orderCellID = @"oderCellID";
    SXOrderCell *cell = [tableView dequeueReusableCellWithIdentifier:orderCellID];
    if (!cell) {
        cell = [[SXOrderCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:orderCellID];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    SXOrderModel *orderModel = self.dataArray[indexPath.row];
    cell.order = orderModel;
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return [self.cellHeightArray[indexPath.row] floatValue];
}
@end
