//
//  SXOrderHeaderView.m
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import "SXCheckHeaderView.h"

@interface SXCheckHeaderView ()<UITextFieldDelegate>


@end

@implementation SXCheckHeaderView {
    UITextField *_tf;
}

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self initSubviews];
    }
    return self;
}

- (void)initSubviews {
    CGFloat leftPadding = 15;
    
    CGFloat btnW = 70;
    
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(leftPadding, 20, 200, 18)];
    label.text = @"请输入服务订单号";
    label.font = [UIFont systemFontOfSize:17];
    label.textColor = [UIColor colorWithHexString:@"585858"];
    [self addSubview:label];
    
    UITextField *tf = [[UITextField alloc] initWithFrame:CGRectMake(leftPadding, label.bottom+15, self.width-15*3-btnW, 44)];
    _tf = tf;
    tf.returnKeyType = UIReturnKeyDone;
    tf.delegate = self;
    tf.placeholder = @"订单号";
    tf.font = [UIFont systemFontOfSize:14];
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 44)];
    rightView.backgroundColor = [UIColor clearColor];
    tf.leftViewMode = UITextFieldViewModeAlways;
    tf.leftView = rightView;
    tf.layer.borderColor = [UIColor colorWithHexString:@"eeeeee"].CGColor;
    tf.layer.borderWidth = 0.5;
    tf.layer.cornerRadius = 3;
    tf.clipsToBounds = YES;
    [self addSubview:tf];
    
    UIButton *checkBtn = [[UIButton alloc] initWithFrame:CGRectMake(self.width-15-btnW, tf.top, btnW, 44)];
    checkBtn.backgroundColor = [UIColor colorWithHexString:@"5ab091"];
    [checkBtn setTitle:@"核销" forState:UIControlStateNormal];
    checkBtn.titleLabel.font = [UIFont systemFontOfSize:17];
    checkBtn.layer.cornerRadius = 5;
    [checkBtn addTarget:self action:@selector(check) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:checkBtn];
 
    UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, self.height-0.5, self.width, 0.5)];
    lineView.backgroundColor = [UIColor colorWithHexString:@"eeeeee"];
    [self addSubview:lineView];
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    [textField resignFirstResponder];
    return  YES;
}

- (void)check {
    [_tf resignFirstResponder];
    if (self.checkBtnOnClickBlock) {
        self.checkBtnOnClickBlock(_tf.text);
    }
}

@end
