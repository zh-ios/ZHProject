//
//  SXOrderModel.m
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import "SXOrderModel.h"

@implementation SXOrderModel

+ (NSArray *)demoData {
    SXOrderModel *o1 = [[SXOrderModel alloc] init];
    o1.phoneNumber = @"11231234";
    o1.date = @"2018-09-10";
    o1.desc = @"高发烧，he搜所所所撒奥奥奥奥奥11111111111萨达是打发阿萨德发这些大法师打发斯蒂芬只晓得发";
    o1.price = 202;
    o1.status = OrderStatus_UnPay;
    o1.orderId = @"sssxxxxx20123123";
    
    SXOrderModel *o2 = [[SXOrderModel alloc] init];
    o2.phoneNumber = @"11231234";
    o2.date = @"2018-09-10";
    o2.desc = @"高发烧，he搜所所所撒奥奥奥奥奥11111111111萨达是打发阿萨德发这些大法师打发斯蒂芬只晓得发";
    o2.price = 202;
    o2.status = OrderStatus_UnPay;
    o2.orderId = @"sssxxxxx20123123";
 
    SXOrderModel *o3 = [[SXOrderModel alloc] init];
    o3.phoneNumber = @"11231234";
    o3.date = @"2018-09-10";
    o3.desc = @"高发烧，he搜所所所撒奥奥奥奥奥11111111111萨达是打发阿萨德发这些大法师打发斯蒂芬只晓得发高发烧，he搜所所所撒奥奥奥奥奥11111111111萨达是打发阿萨德发这些大法师打发斯蒂芬只晓得发高发烧，he搜所所所撒奥奥奥奥奥11111111111萨达是打发阿萨德发这些大法师打发斯蒂芬只晓得发";
    o3.price = 111;
//    o3.status = OrderStatus_UnDeal;
    o3.orderId = @"sssxxxxx20123123";
    
    SXOrderModel *o4 = [[SXOrderModel alloc] init];
    o4.phoneNumber = @"11231234";
    o4.date = @"2018-09-10";
    o4.desc = @"阿萨德发这些大法师打发斯蒂芬只晓得发";
    o4.price = 202;
    o4.status = OrderStatus_Finished;
    o4.orderId = @"sssxxxxx20123123";
    
    SXOrderModel *o5 = [[SXOrderModel alloc] init];
    o5.phoneNumber = @"11231234";
    o5.date = @"2018-09-10";
    o5.desc = @"高发烧";
    o5.price = 202;
    o5.status = OrderStatus_UnPay;
    o5.orderId = @"sssxxxxx20123123";
    return @[o1,o2,o3,o4,o5];
}

@end
