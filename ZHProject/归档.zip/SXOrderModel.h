//
//  SXOrderModel.h
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

typedef NS_ENUM(NSInteger, OrderStatus) {
    OrderStatus_UnDeal = 1, // 未核销订单
    OrderStatus_UnPay, // 已经核销，未结算
    OrderStatus_Finished  // 已结算
};

@interface SXOrderModel : NSObject

@property (nonatomic, copy) NSString *avatar;
@property (nonatomic, copy) NSString *phoneNumber;

/**
 订单日期
 */
@property (nonatomic, copy) NSString *date;

/**
 订单描述
 */
@property (nonatomic, copy) NSString *desc;
@property (nonatomic, copy) NSString *orderId;

@property (nonatomic, assign) CGFloat price;

/**
  订单状态
 */
@property (nonatomic, assign) OrderStatus status;

+ (NSArray *)demoData;

@end

NS_ASSUME_NONNULL_END
