//
//  SXOrderCheckControlller.m
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import "SXOrderCheckControlller.h"
#import "SXOrderCell.h"

#import "SXOrderModel.h"
#import "SXCheckHeaderView.h"
#import "SXOrderView.h"
@interface SXOrderCheckControlller ()<UITableViewDelegate,UITableViewDataSource>

@property (nonatomic, strong) UITableView *tableView;

@end

@implementation SXOrderCheckControlller

- (UITableView *)tableView {
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, kNavbarHeight, self.view.width, self.view.height-kNavbarHeight-kTabbarHeight) style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
        _tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    }
    return _tableView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"订单核销";

    SXOrderView *orderView = [[SXOrderView alloc] initWithFrame:CGRectMake(0, kNavbarHeight, self.view.width, self.view.height-kNavbarHeight-kTabbarHeight)];
    [self.view addSubview:orderView];
    orderView.dataArray = [SXOrderModel demoData];
    
    SXCheckHeaderView *headerView = [[SXCheckHeaderView alloc] initWithFrame:CGRectMake(0, 0, self.view.width, 110)];
    __weak typeof(self)weakSelf = self;
    
    headerView.checkBtnOnClickBlock = ^(NSString * orderId){
        __strong typeof(weakSelf)strongSelf = weakSelf;
        
    };
    orderView.tableView.tableHeaderView = headerView;
}


@end
