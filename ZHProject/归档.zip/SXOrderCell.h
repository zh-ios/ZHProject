//
//  SXOrderCell.h
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "SXOrderModel.h"

NS_ASSUME_NONNULL_BEGIN

@interface SXOrderCell : UITableViewCell

@property (nonatomic, strong) SXOrderModel *order;

@end

NS_ASSUME_NONNULL_END
