//
//  SXOrderCell.m
//  ZHProject
//
//  Created by zh on 2018/10/17.
//  Copyright © 2018年 autohome. All rights reserved.
//

#import "SXOrderCell.h"

@interface SXOrderCell ()

@property (nonatomic, strong) UIImageView *avatarImg;
@property (nonatomic, strong) UILabel *phoneL;
@property (nonatomic, strong) UILabel *dateL;
@property (nonatomic, strong) UILabel *descL;
@property (nonatomic, strong) UILabel *orderIdL;
@property (nonatomic, strong) UILabel *priceL;
@property (nonatomic, strong) UILabel *statusL;
@property (nonatomic, strong) UILabel *lineL;
@end

@implementation SXOrderCell


- (void)setOrder:(SXOrderModel *)order {
    _order = order;
    
    // FIXME: 添加头像
//    self.avatarImg
    
    
    
    self.phoneL.text = order.phoneNumber;
    self.dateL.text = order.date;
    self.descL.text = order.desc;
    self.orderIdL.text = order.orderId;
    self.priceL.text = [NSString stringWithFormat:@"¥ %@",@(order.price)];
    
    if (order.status == OrderStatus_UnDeal) {
        self.statusL.text = @"未核销";
        self.statusL.hidden = NO;
    }
    if (order.status == OrderStatus_UnPay) {
        self.statusL.text = @"已核销 未计算";
        self.statusL.hidden = NO;
    }
    if (order.status == OrderStatus_Finished) {
        self.statusL.text = @"已结算";
        self.statusL.hidden = NO;
        self.statusL.backgroundColor = [UIColor colorWithHexString:@"eaf5f2"];
        self.statusL.textColor = [UIColor colorWithHexString:@"5ab091"];
    }
}


- (instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        [self initSubviews];
    }
    return self;
}

- (void)initSubviews {
    self.avatarImg = [[UIImageView alloc] init];
    self.avatarImg.layer.masksToBounds = YES;
    self.avatarImg.backgroundColor = [UIColor lightGrayColor];
    self.avatarImg.contentMode = UIViewContentModeScaleAspectFill;
    
    self.phoneL = [[UILabel alloc] init];
    self.phoneL.textColor = [UIColor colorWithHexString:@"9a9a9a"];
    self.phoneL.font = [UIFont systemFontOfSize:15];
    
    self.dateL = [[UILabel alloc] init];
    self.dateL.textColor = [UIColor colorWithHexString:@"9a9a9a"];
    self.dateL.font = [UIFont systemFontOfSize:13];
    
    self.descL = [[UILabel alloc] init];
    self.descL.textColor = [UIColor colorWithHexString:@"585858"];
    self.descL.font = [UIFont systemFontOfSize:17];
    self.descL.numberOfLines = 0;
    
    self.orderIdL = [[UILabel alloc] init];
    self.orderIdL.textColor = [UIColor colorWithHexString:@"9a9a9a"];
    self.orderIdL.font = [UIFont systemFontOfSize:13];
    
    self.priceL = [[UILabel alloc] init];
    self.priceL.textColor = [UIColor orangeColor];
    self.priceL.font = [UIFont systemFontOfSize:17];
    self.priceL.textAlignment = NSTextAlignmentRight;
    
    self.statusL = [[UILabel alloc] init];
    self.statusL.font = [UIFont systemFontOfSize:13];
    self.statusL.textAlignment = NSTextAlignmentCenter;
    self.statusL.hidden = YES;
    self.statusL.textColor = [UIColor orangeColor];
    self.statusL.backgroundColor = [UIColor colorWithHexString:@"f8f5f0"];
    
    UILabel *lineL = [[UILabel alloc] init];
    lineL.backgroundColor = [UIColor colorWithHexString:@"eeeeee"];
    self.lineL = lineL;
    
    [self.contentView addSubview:self.avatarImg];
    [self.contentView addSubview:self.phoneL];
    [self.contentView addSubview:self.dateL];
    [self.contentView addSubview:self.descL];
    [self.contentView addSubview:self.orderIdL];
    [self.contentView addSubview:self.priceL];
    [self.contentView addSubview:self.statusL];
    [self.contentView addSubview:lineL];
}

- (void)layoutSubviews {
    [super layoutSubviews];
    CGFloat leftPadding = 15;
    CGFloat margin = 15;
    CGFloat descLRightPadding = 130;
    
    self.avatarImg.frame = CGRectMake(leftPadding, leftPadding, 50, 50);
    self.avatarImg.layer.cornerRadius = self.avatarImg.width*0.5;
    
    self.phoneL.frame = CGRectMake(self.avatarImg.right+10, self.avatarImg.top, 150, 16);
    self.dateL.frame = CGRectMake(self.phoneL.left, self.phoneL.bottom+margin, 200, 14);
    CGSize descSize = [self.order.desc boundingRectWithSize:CGSizeMake(self.width-descLRightPadding, CGFLOAT_MAX) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : self.descL.font} context:nil].size;
    
    self.descL.frame = CGRectMake(leftPadding, self.avatarImg.bottom + margin, self.width-descLRightPadding, descSize.height);
    self.orderIdL.frame = CGRectMake(leftPadding, self.descL.bottom+margin, 200, 14);
    self.priceL.frame = CGRectMake(self.width-leftPadding-80, self.descL.top, 80, 20);
    [self.statusL sizeToFit];
    self.statusL.frame = CGRectMake(self.width-leftPadding-self.statusL.width-20, self.orderIdL.top, self.statusL.width+20, 20);
    self.statusL.layer.cornerRadius = self.statusL.height*0.5;
    self.statusL.layer.masksToBounds = YES;
    self.lineL.frame = CGRectMake(leftPadding, self.height-0.5, self.width-leftPadding*2, 0.5);
    
    
}

@end
